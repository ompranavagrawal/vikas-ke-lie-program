package com.example.RailwayReservationSystem_157753_1;

public class RailwayReservationException extends Exception {

	public RailwayReservationException(String msg) {
		super(msg);

      }
}


